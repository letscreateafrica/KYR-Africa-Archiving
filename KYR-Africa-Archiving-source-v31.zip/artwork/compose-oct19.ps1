$root = 'C:\Users\HP\Documents\Codex\2026-10-12\maintain-the-existing-public-knowyourrights-africa\work\site-checkout-current'
$art = Join-Path $root 'artwork\source-art\2026-10-18.png'
$output = Join-Path $root 'src\posters\2026-10-19-visual.jpg'
Add-Type -AssemblyName System.Drawing
$source = [System.Drawing.Image]::FromFile($art)
$width = 1024
$artHeight = [int][Math]::Round($source.Height * $width / $source.Width)
$header = 380
$footer = 230
$page = [System.Drawing.Bitmap]::new($width, $header + $artHeight + $footer)
$g = [System.Drawing.Graphics]::FromImage($page)
$g.SmoothingMode = 'HighQuality'
$g.InterpolationMode = 'HighQualityBicubic'
$green = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(16,60,46))
$white = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$gold = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(255,207,54))
$pale = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(219,232,242))
$g.FillRectangle($green,0,0,$width,$page.Height)
$g.DrawImage($source,0,$header,$width,$artHeight)
$bold = [System.Drawing.FontStyle]::Bold
$brand = [System.Drawing.Font]::new('Segoe UI',55,$bold)
$dateFont = [System.Drawing.Font]::new('Segoe UI',24,$bold)
$titleFont = [System.Drawing.Font]::new('Georgia',47,$bold)
$small = [System.Drawing.Font]::new('Segoe UI',22)
$smallBold = [System.Drawing.Font]::new('Segoe UI',22,$bold)
$siteFont = [System.Drawing.Font]::new('Segoe UI',16)
$g.DrawString('KnowYourRights', $brand, $white, 50, 22)
$brandWidth = $g.MeasureString('KnowYourRights', $brand).Width
$g.DrawString('Africa', $brand, $gold, (50 + $brandWidth - 4), 22)
$g.DrawString('VISUAL NEWSLETTER  /  OCTOBER 19, 2026', $dateFont, $gold, 54, 133)
$g.DrawLine([System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(255,207,54),3),54,186,970,186)
$g.DrawString('October 19: a limited', $titleFont, $white, 54, 207)
$g.DrawString('no-update review', $titleFont, $white, 54, 277)
$footY = $header + $artHeight
$g.FillRectangle($gold,0,$footY,$width,12)
$g.DrawString('REUSED FIRST-PARTY ARTWORK  •  PRESENTATION, NOT EVIDENCE', $smallBold, $gold, 54, ($footY+32))
$g.DrawString('Source links and coverage limits are in the written newsletter.', $small, $white, 54, ($footY+82))
$g.DrawString('Information, not individual legal advice.', $small, $pale, 54, ($footY+119))
$g.DrawString('https://african-diaspora-brief-october-5-2026.letscreateafrica.chatgpt.site', $siteFont, $white, 54, ($footY+169))
$encoder = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object MimeType -eq 'image/jpeg' | Select-Object -First 1
$params = [System.Drawing.Imaging.EncoderParameters]::new(1)
$params.Param[0] = [System.Drawing.Imaging.EncoderParameter]::new([System.Drawing.Imaging.Encoder]::Quality,[long]84)
$page.Save($output,$encoder,$params)
$g.Dispose(); $page.Dispose(); $source.Dispose()
Get-Item $output | Select-Object FullName,Length
