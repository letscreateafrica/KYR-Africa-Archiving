import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const data = JSON.parse(fs.readFileSync(path.join(root, 'content.json'), 'utf8'));
const output = path.join(root, 'dist', 'banners');
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const safe = value => {
  if (!/^[a-z0-9-]+$/.test(value)) throw new Error(`Unsafe visual identifier: ${value}`);
  return value;
};
const titleKey = title => safe(String(title).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 64));
export const bannerUrl = (date, id, title) => `/banners/${safe(date)}/${safe(id)}-${titleKey(title)}.svg`;
export const bannerMarkup = (date, item, label = 'Story') => {
  const url = bannerUrl(date, item.id, item.title);
  return `<figure class="story-banner"><img src="${url}" alt="Editorial visual banner for ${esc(item.title)}; not evidence" width="960" height="340" loading="lazy"><figcaption>${esc(label)} visual · original editorial illustration, not evidence. Verify the linked source below.</figcaption></figure>`;
};
export const visualEvidenceMarkup = item => {
  const document = (item.sources || []).find(source => source.primary && (/\.pdf(?:$|[?#])/i.test(source.url) || (/justice\.gov\/eoir\/media\/\d+\/dl/i.test(source.url) && /\bPDF\b/i.test(source.title))));
  return document
    ? `<p class="visual-evidence">Story-specific official document: <a href="${esc(document.url)}" rel="noreferrer">${esc(document.title)} (PDF)</a>. The editorial banner is separate from this evidence.</p>`
    : '<p class="visual-evidence">No verified visual found. The editorial banner is not evidence; read the linked source text below.</p>';
};

function lines(value, max = 38) {
  const result = [];
  for (const word of String(value).split(/\s+/)) {
    if (!result.length || `${result.at(-1)} ${word}`.length > max) result.push(word);
    else result[result.length - 1] += ` ${word}`;
  }
  if (result.length > 3) return [...result.slice(0, 2), `${result[2]}…`];
  return result;
}
function sceneKind(item) {
  const title = String(item.title).toLowerCase();
  if (/fee|penalt/.test(title)) return /enforcement|penalt/.test(title) ? 'appeal' : 'fees';
  if (/travel|visa|parole/.test(title)) return 'passport';
  if (/refugee status|termination|directive/.test(title)) return 'notice';
  if (/ead|employment/.test(title)) return 'work';
  if (/supreme court|court|challenge|deference|legal/.test(title)) return 'court';
  if (/tariff|export|dialogue/.test(title)) return 'trade';
  if (/scam|trafficking/.test(title)) return 'shield';
  if (/biometric/.test(title)) return 'fingerprint';
  if (/asylum registration/.test(title)) return 'registration';
  if (/death.penalty|safeguard/.test(title)) return 'scales';
  if (/diaspora|african union/.test(title)) return 'network';
  if (/head start/.test(title)) return 'family';
  if (/shipwreck/.test(title)) return 'sea';
  return 'document';
}
function sceneSvg(kind, accent) {
  const paper = '#f8f2df', ink = '#174137';
  const scenes = {
    fees: `<rect x="705" y="62" width="176" height="219" rx="8" fill="${paper}" transform="rotate(7 793 172)"/><path d="M740 111h94m-94 25h74m-74 25h91" stroke="${ink}" stroke-width="8" stroke-linecap="round"/><circle cx="837" cy="222" r="31" fill="${accent}"/><text x="837" y="232" text-anchor="middle" fill="${ink}" font-size="30" font-weight="bold" font-family="Arial">$</text>`,
    passport: `<rect x="714" y="65" width="162" height="220" rx="13" fill="${paper}" transform="rotate(-8 795 175)"/><circle cx="787" cy="159" r="49" fill="none" stroke="${ink}" stroke-width="5"/><path d="M740 159h94m-47-48c-24 27-24 68 0 96m0-96c24 27 24 68 0 96" fill="none" stroke="${ink}" stroke-width="4"/><path d="m835 88 54-30-18 35 23 11-75 20z" fill="${accent}"/>`,
    notice: `<rect x="712" y="65" width="166" height="212" rx="8" fill="${paper}"/><path d="M740 105h102m-102 24h80m-80 24h89" stroke="${ink}" stroke-width="7" stroke-linecap="round"/><circle cx="847" cy="225" r="42" fill="${accent}" stroke="${ink}" stroke-width="4"/><path d="M847 201v26l18 10" fill="none" stroke="${ink}" stroke-width="6" stroke-linecap="round"/>`,
    work: `<rect x="692" y="79" width="202" height="174" rx="15" fill="${paper}"/><rect x="715" y="105" width="60" height="70" rx="7" fill="${accent}"/><circle cx="745" cy="132" r="12" fill="${ink}"/><path d="M722 169q23-34 46 0m29-52h65m-65 25h56m-133 63h144" fill="none" stroke="${ink}" stroke-width="7" stroke-linecap="round"/><path d="M775 79v-25h34v25" fill="none" stroke="${paper}" stroke-width="9"/>`,
    court: `<path d="M692 130 790 70l98 60z" fill="${accent}"/><rect x="705" y="242" width="172" height="16" fill="${paper}"/><rect x="712" y="263" width="157" height="16" fill="${accent}"/>${[725,767,809,851].map(x=>`<rect x="${x}" y="139" width="20" height="94" fill="${paper}"/>`).join('')}`, 
    trade: `<path d="M680 227h210l-25 42H710z" fill="${paper}"/><rect x="716" y="167" width="72" height="58" fill="${accent}"/><rect x="792" y="167" width="72" height="58" fill="#e8d8aa"/><path d="M712 163V89h153m-39 0v69m0-69 35 35" fill="none" stroke="${paper}" stroke-width="8"/><path d="M690 286q24-13 48 0t48 0t48 0t48 0" fill="none" stroke="${accent}" stroke-width="6"/>`,
    shield: `<path d="M790 66 879 100v82q-8 67-89 106-81-39-89-106v-82z" fill="${paper}"/><path d="M790 88 852 111v69q-7 45-62 76-55-31-62-76v-69z" fill="${accent}"/><path d="m755 179 25 24 47-58" fill="none" stroke="${ink}" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>`,
    fingerprint: `<circle cx="790" cy="173" r="106" fill="${paper}"/>${[32,48,64,80].map(r=>`<path d="M${790-r} 207v-38a${r} ${r} 0 0 1 ${r*2} 0v48" fill="none" stroke="${ink}" stroke-width="5" stroke-linecap="round"/>`).join('')}<path d="M790 257v-76" stroke="${ink}" stroke-width="5"/>`,
    registration: `<rect x="706" y="112" width="170" height="158" fill="${paper}"/><path d="m690 115 101-53 101 53z" fill="${accent}"/><rect x="764" y="194" width="52" height="76" fill="${ink}"/><path d="M729 149h22m79 0h22m-123 25h22m79 0h22" stroke="${ink}" stroke-width="8"/>`,
    scales: `<path d="M790 75v188m-65-164h130m-65-16v-18m-28 198h56" stroke="${paper}" stroke-width="9" stroke-linecap="round"/><path d="m725 100-34 91h69zm130 0-34 91h69z" fill="${accent}"/><path d="M691 191q34 50 69 0m61 0q34 50 69 0" fill="none" stroke="${paper}" stroke-width="7"/>`,
    network: `<circle cx="790" cy="174" r="92" fill="${paper}"/><path d="M700 174h180M790 82v184M730 108q116 73 0 132m120-132q-116 73 0 132" fill="none" stroke="${ink}" stroke-width="4"/>${[[704,174],[790,83],[875,174],[790,265],[731,111],[849,237]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="11" fill="${accent}"/>`).join('')}`,
    family: `<path d="M692 214q96-48 196 0v65q-96-43-196 0z" fill="${paper}"/><path d="M790 174v96" stroke="${ink}" stroke-width="5"/><circle cx="750" cy="130" r="21" fill="${accent}"/><circle cx="830" cy="130" r="21" fill="${accent}"/><circle cx="790" cy="159" r="17" fill="${paper}"/><path d="M711 194q38-78 77 4m5 0q39-82 78-4" fill="none" stroke="${paper}" stroke-width="11"/>`,
    sea: `<path d="M694 195h192l-24 41H718z" fill="${paper}"/><path d="M790 93v102m0-92 75 80h-75z" fill="${accent}"/><path d="M692 256q24-12 48 0t48 0t48 0t48 0m-192 24q24-12 48 0t48 0t48 0t48 0" fill="none" stroke="${paper}" stroke-width="7"/>`,
    appeal: `<rect x="706" y="76" width="150" height="190" rx="8" fill="${paper}"/><path d="M733 111h94m-94 24h80m-80 24h89" stroke="${ink}" stroke-width="7"/><circle cx="850" cy="226" r="43" fill="${accent}"/><path d="M850 202v29m-16 0h32m-31 0-14 17h28m16-17 14 17h-28" fill="none" stroke="${ink}" stroke-width="5"/>`,
    document: `<rect x="710" y="68" width="166" height="209" rx="8" fill="${paper}"/><path d="M737 109h105m-105 28h91m-91 28h100m-100 28h74" stroke="${ink}" stroke-width="8" stroke-linecap="round"/><circle cx="835" cy="235" r="27" fill="${accent}"/>`
  };
  return `<circle cx="790" cy="170" r="129" fill="${accent}" opacity=".12"/>${scenes[kind] || scenes.document}`;
}
function draw(date, item, pillar) {
  const colors = pillar === 'African Diaspora Brief'
    ? {background:'#154e40',accent:'#e5b75c',pale:'#d6ead9'}
    : pillar === 'Policy Alerts'
      ? {background:'#263e47',accent:'#e5b75c',pale:'#e7efe8'}
      : {background:'#173e35',accent:'#d9bd75',pale:'#d6ead9'};
  const title = lines(item.title);
  const label = pillar.toUpperCase();
  const status = String(item.status || 'Source reviewed').slice(0, 63);
  const kind = sceneKind(item);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="340" viewBox="0 0 960 340" role="img" aria-labelledby="title desc"><title id="title">${esc(item.title)} editorial visual</title><desc id="desc">Dated ${esc(date)} ${esc(pillar)} banner with a ${esc(kind)} illustration. Presentation only; primary evidence is linked in the article.</desc><rect width="960" height="340" fill="${colors.background}"/><path d="M42 68h560" stroke="${colors.accent}" stroke-width="3"/><text x="42" y="43" fill="${colors.accent}" font-family="Arial,sans-serif" font-weight="700" font-size="20">${esc(date)} · ${esc(label)}</text>${title.map((line,index)=>`<text x="42" y="${132+index*52}" fill="#fff" font-family="Georgia,serif" font-size="42">${esc(line)}</text>`).join('')}<text x="42" y="287" fill="${colors.pale}" font-family="Arial,sans-serif" font-size="17">${esc(status)}</text><text x="42" y="320" fill="${colors.pale}" font-family="Arial,sans-serif" font-size="14">EDITORIAL ILLUSTRATION · NOT EVIDENCE</text>${sceneSvg(kind, colors.accent)}</svg>`;
  const dir = path.join(output, safe(date));
  fs.mkdirSync(dir, {recursive:true});
  fs.writeFileSync(path.join(dir, `${safe(item.id)}-${titleKey(item.title)}.svg`), svg);
}
for (const edition of data.editions.filter(entry => entry.type !== 'Legacy archive')) {
  edition.items.forEach((item, index) => draw(edition.date, {...item, id:item.id || `entry-${index+1}`}, item.topic));
  for (const item of edition.reportedItems || []) draw(edition.date, item, 'U.S. Immigrant Brief');
  for (const alert of data.alerts.filter(entry => (entry.newsDate === edition.date || entry.checkedAt === edition.date) && entry.verification === 'verified')) draw(edition.date, alert, 'Policy Alerts');
}
console.log('Prepared dated editorial banners for newsletter stories and alerts.');
