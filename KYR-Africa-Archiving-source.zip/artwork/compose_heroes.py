"""Compose dated, source-labelled newsletter artwork from retained image assets.

The artwork illustrates the written issue. Facts and legal status remain in the
linked primary records, never in the generated background image.
"""

from __future__ import annotations

import json
from datetime import date
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
POSTERS = ROOT / "src" / "posters"
WIDTH = 1024
NAVY = "#082e56"
GOLD = "#ffcf36"
WHITE = "#ffffff"
PALE = "#dbe8f2"
SITE = "https://african-diaspora-brief-october-5-2026.letscreateafrica.chatgpt.site"
TRACKER_ART = {"2026-10-09", "2026-10-12"}


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    name = "segoeuib.ttf" if bold else "segoeui.ttf"
    return ImageFont.truetype(str(Path("C:/Windows/Fonts") / name), size)


def fit_font(draw: ImageDraw.ImageDraw, value: str, limit: int, start: int, bold: bool = False):
    for size in range(start, 15, -1):
        selected = font(size, bold)
        if draw.textbbox((0, 0), value, font=selected)[2] <= limit:
            return selected
    return font(16, bold)


def wrapped(draw: ImageDraw.ImageDraw, value: str, selected: ImageFont.FreeTypeFont, limit: int):
    lines: list[str] = []
    for word in value.split():
        trial = f"{lines[-1]} {word}" if lines else word
        if lines and draw.textbbox((0, 0), trial, font=selected)[2] > limit:
            lines.append(word)
        elif lines:
            lines[-1] = trial
        else:
            lines.append(word)
    return lines


def compose(issue: dict) -> None:
    issue_date = issue["date"]
    source = (
        POSTERS / f"{issue_date}-hero.png"
        if issue_date == "2026-10-09"
        else POSTERS / "2026-10-12-original.png"
        if issue_date == "2026-10-12"
        else ROOT / "artwork" / "source-art" / "2026-10-18.png"
        if issue_date == "2026-10-19"
        else ROOT / "artwork" / "source-art" / f"{issue_date}.png"
    )
    artwork = Image.open(source).convert("RGB")
    artwork = artwork.resize((WIDTH, round(artwork.height * WIDTH / artwork.width)), Image.Resampling.LANCZOS)

    header = 380
    footer = 230
    background = "#103c2e" if issue_date >= "2026-10-17" else NAVY
    page = Image.new("RGB", (WIDTH, header + artwork.height + footer), background)
    page.paste(artwork, (0, header))
    draw = ImageDraw.Draw(page)

    brand_left = "KnowYourRights"
    brand_font = font(66, True)
    draw.text((50, 38), brand_left, font=brand_font, fill=WHITE)
    brand_width = draw.textbbox((0, 0), brand_left, font=brand_font)[2]
    draw.text((56 + brand_width, 38), "Africa", font=brand_font, fill=GOLD)

    display_date = f"{date.fromisoformat(issue_date).strftime('%B')} {date.fromisoformat(issue_date).day}, {date.fromisoformat(issue_date).year}"
    draw.text((54, 139), f"VISUAL NEWSLETTER  /  {display_date.upper()}", font=font(29, True), fill=GOLD)
    draw.line((54, 185, WIDTH - 54, 185), fill=GOLD, width=3)

    title = issue["title"]
    title_font = font(51, True)
    lines = wrapped(draw, title, title_font, WIDTH - 108)
    while len(lines) > 3:
        title_font = font(title_font.size - 2, True)
        lines = wrapped(draw, title, title_font, WIDTH - 108)
    for index, line in enumerate(lines):
        draw.text((54, 204 + index * (title_font.size + 9)), line, font=title_font, fill=WHITE)

    foot = header + artwork.height
    draw.rectangle((0, foot, WIDTH, foot + 12), fill=GOLD)
    origin = "ORIGINAL TRACKER ARTWORK" if issue_date in TRACKER_ART else "REUSED FIRST-PARTY ARTWORK" if issue_date == "2026-10-19" else "NEW EDITORIAL ILLUSTRATION"
    draw.text((54, foot + 32), f"{origin}  •  PRESENTATION, NOT EVIDENCE", font=font(25, True), fill=GOLD)
    draw.text((54, foot + 82), "Source links and coverage limits are in the written newsletter.", font=font(24), fill=WHITE)
    draw.text((54, foot + 119), "Information, not individual legal advice.", font=font(24), fill=PALE)
    site_font = fit_font(draw, SITE, WIDTH - 108, 24)
    draw.text((54, foot + 169), SITE, font=site_font, fill=WHITE)

    output = POSTERS / f"{issue_date}-visual.webp"
    page.save(output, "WEBP", quality=83, method=6)
    print(f"{issue_date}: {output.relative_to(ROOT)} ({output.stat().st_size:,} bytes)")


if __name__ == "__main__":
    content = json.loads((ROOT / "content.json").read_text(encoding="utf-8"))
    import sys
    for newsletter in content["newsletters"]:
        if len(sys.argv) > 1 and newsletter["date"] != sys.argv[1]:
            continue
        compose(newsletter)
