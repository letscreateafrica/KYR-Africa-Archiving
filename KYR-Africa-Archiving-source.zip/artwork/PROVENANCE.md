# Dated newsletter artwork

The published hero images in `src/posters/*-visual.webp` are editorial presentation. The story claims, status, dates, and coverage limits are established only by the written newsletter and its linked sources. The footer of each image states this distinction and gives the public Site URL and general-information notice.

October 9 and October 12 use retained original U.S. Immigrant Brief tracker images (`src/posters/2026-10-09-hero.png` and `src/posters/2026-10-12-original.png`) as the underlying artwork. The overlaid titles and dates refer to this Site's source-reviewed newsletter, whose written qualifications take precedence over any earlier text embedded in the tracker image.

October 10, 11, 13, 14, 15, and 16 use new generated artwork stored in `artwork/source-art/`. The original tracker chat exposed image placeholders for these dates, but no retrievable image files. These images do not claim to reproduce tracker art.

## New illustration prompts

Each prompt requested a rich, text-free, portrait editorial collage for the KnowYourRights Africa visual newsletter, using dark indigo, emerald, warm gold, and clear space for later typesetting. Date-specific subjects were:

| Date | Art direction |
| --- | --- |
| October 10 | African human-rights advocacy, justice scales, civic safeguards, West African design cues. |
| October 11 | South African asylum registration and service access, queues, paperwork, and a civic building. |
| October 13 | West African cross-border public-safety work, a protective shield and communication networks. |
| October 14 | A seven-topic collage of immigration procedure, court review, work authorization, exports and rights. |
| October 15 | A quiet research desk and restrained no-qualifying-update composition; no fabricated breaking event. |
| October 16 | Fee schedules, travel documents and filing decisions, with African diaspora readers in the U.S. |
| October 18 | A quiet source-review desk with calendar, laptop and Africa motif; no depicted policy event. Generated as original editorial illustration. |

The October 18 image is `artwork/source-art/2026-10-18.png`, generated with the built-in image tool for this issue. The dated, 328 KB `src/posters/2026-10-18-visual.jpg` composites the exact newsletter title, public Site address and both notices. The Windows Python launcher was unavailable in this run, so the equivalent dated composition was made with `artwork/compose-oct18.ps1`. Neither asset is evidence.

No generated image is evidence. `compose_heroes.py` adds the exact issue title, date, site link and notices from `content.json`; rerun it after any title change.
