import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const data = JSON.parse(fs.readFileSync(path.join(root, 'content.json'), 'utf8'));
const output = path.join(root, 'dist', 'banners');
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const safe = value => {
  if (!/^[a-z0-9-]+$/.test(value)) throw new Error(`Unsafe visual identifier: ${value}`);
  return value;
};
export const bannerUrl = (date, id) => `/banners/${safe(date)}/${safe(id)}.svg`;
export const bannerMarkup = (date, item, label = 'Story') => {
  const url = bannerUrl(date, item.id);
  return `<figure class="story-banner"><img src="${url}" alt="Editorial visual banner for ${esc(item.title)}; not evidence" width="960" height="340" loading="lazy"><figcaption>${esc(label)} visual · original editorial illustration, not evidence. Verify the linked source below.</figcaption></figure>`;
};
export const visualEvidenceMarkup = item => {
  const document = (item.sources || []).find(source => source.primary && /\.pdf(?:$|[?#])/i.test(source.url));
  return document
    ? `<p class="visual-evidence">Story-specific official document: <a href="${esc(document.url)}" rel="noreferrer">${esc(document.title)} (PDF)</a>. The editorial banner is separate from this evidence.</p>`
    : '<p class="visual-evidence">No verified visual found. The editorial banner is not evidence; read the linked source text below.</p>';
};

function lines(value, max = 38) {
  const result = [];
  for (const word of String(value).split(/\s+/)) {
    if (!result.length || `${result.at(-1)} ${word}`.length > max) result.push(word);
    else result[result.length - 1] += ` ${word}`;
  }
  if (result.length > 3) return [...result.slice(0, 2), `${result[2]}…`];
  return result;
}
function draw(date, item, pillar) {
  const colors = pillar === 'African Diaspora Brief'
    ? {background:'#154e40',accent:'#e5b75c',pale:'#d6ead9'}
    : pillar === 'Policy Alerts'
      ? {background:'#263e47',accent:'#e5b75c',pale:'#e7efe8'}
      : {background:'#173e35',accent:'#d9bd75',pale:'#d6ead9'};
  const title = lines(item.title);
  const label = pillar.toUpperCase();
  const status = String(item.status || 'Source reviewed').slice(0, 63);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="340" viewBox="0 0 960 340" role="img" aria-labelledby="title desc"><title id="title">${esc(item.title)} editorial visual</title><desc id="desc">Dated ${esc(date)} ${esc(pillar)} banner. Illustration only; primary evidence is linked in the article.</desc><rect width="960" height="340" fill="${colors.background}"/><circle cx="875" cy="30" r="145" fill="none" stroke="${colors.accent}" stroke-width="7" opacity=".8"/><circle cx="790" cy="190" r="105" fill="none" stroke="${colors.pale}" stroke-width="2" opacity=".5"/><path d="M42 68h560" stroke="${colors.accent}" stroke-width="3"/><text x="42" y="43" fill="${colors.accent}" font-family="Arial,sans-serif" font-weight="700" font-size="20">${esc(date)} · ${esc(label)}</text>${title.map((line,index)=>`<text x="42" y="${132+index*52}" fill="#fff" font-family="Georgia,serif" font-size="42">${esc(line)}</text>`).join('')}<text x="42" y="287" fill="${colors.pale}" font-family="Arial,sans-serif" font-size="17">${esc(status)}</text><text x="42" y="320" fill="${colors.pale}" font-family="Arial,sans-serif" font-size="14">EDITORIAL ILLUSTRATION · NOT EVIDENCE</text></svg>`;
  const dir = path.join(output, safe(date));
  fs.mkdirSync(dir, {recursive:true});
  fs.writeFileSync(path.join(dir, `${safe(item.id)}.svg`), svg);
}
for (const edition of data.editions.filter(entry => entry.type !== 'Legacy archive')) {
  edition.items.forEach((item, index) => draw(edition.date, {...item, id:item.id || `entry-${index+1}`}, item.topic));
  for (const item of edition.reportedItems || []) draw(edition.date, item, 'U.S. Immigrant Brief');
  for (const alert of data.alerts.filter(entry => (entry.newsDate === edition.date || entry.checkedAt === edition.date) && entry.verification === 'verified')) draw(edition.date, alert, 'Policy Alerts');
}
console.log('Prepared dated editorial banners for newsletter stories and alerts.');
