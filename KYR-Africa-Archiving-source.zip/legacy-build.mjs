import fs from 'node:fs';
import { marked } from 'file:///C:/Users/HP/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/marked/lib/marked.esm.js';

const editions = [
  {
    slug: '2026-10-07',
    title: 'African Diaspora Daily Brief | October 7, 2026',
    description: 'October 7, 2026 brief for African immigrants and diaspora communities in the United States, with sources, visuals, coverage lists, and verification limits.',
    source: './editions/2026-10-07.md',
  },
  {
    slug: '2026-10-05',
    title: 'African Diaspora Daily Brief | October 5, 2026',
    description: 'October 5, 2026 brief for African immigrants and diaspora communities in the United States, with sources, visuals, coverage lists, and verification limits.',
    source: './editions/2026-10-05.md',
  },
];

const favicon = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='4' fill='%23165e49'/%3E%3Cpath d='M8 8h16v3H8zm0 6h16v3H8zm0 6h10v3H8z' fill='white'/%3E%3C/svg%3E";
const styles = `:root{color-scheme:light;font-family:Georgia,'Times New Roman',serif;color:#202529;background:#fff;line-height:1.7}
*{box-sizing:border-box}body{margin:0;border-top:6px solid #165e49}main{max-width:900px;margin:0 auto;padding:36px 28px 80px}
nav{font-family:Arial,Helvetica,sans-serif;margin-bottom:28px;display:flex;gap:14px;flex-wrap:wrap}nav a{font-size:.95rem}
h1,h2,h3{font-family:Arial,Helvetica,sans-serif;line-height:1.25;letter-spacing:0}h1{font-size:2.25rem;margin:0 0 24px}h2{font-size:1.5rem;margin-top:48px;padding-top:20px;border-top:1px solid #d5ddda;color:#165e49}h3{font-size:1.15rem;margin-top:32px}
p,li{font-size:1.0625rem}a{color:#145ca1;text-underline-offset:3px;overflow-wrap:anywhere}img{display:block;max-width:100%;max-height:350px;width:auto;height:auto;margin:20px auto;object-fit:contain}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f4;padding:20px;font-size:.9375rem}code{overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;display:block;overflow-x:auto}th,td{padding:10px;border:1px solid #d5ddda}blockquote{border-left:3px solid #165e49;margin-left:0;padding-left:20px}hr{border:0;border-top:1px solid #d5ddda}.edition-list{padding-left:1.1rem}.lede{font-family:Arial,Helvetica,sans-serif;font-size:1.1rem}
@media(max-width:560px){main{padding:24px 18px 48px}h1{font-size:1.75rem}h2{font-size:1.3rem}img{max-height:260px}}
@media print{main{max-width:none;padding:0}a{color:inherit}nav{display:none}h2,h3{break-after:avoid}img{max-height:220px}}`;

function page({ title, description, body }) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<meta name="description" content="${description}">
<link rel="icon" type="image/svg+xml" href="${favicon}">
<style>${styles}</style></head><body><main><nav><a href="/latest-brief/">Latest brief</a><a href="/archive/">Archive</a><a href="/archive/2026-10-05/">October 5, 2026</a></nav>${body}</main></body></html>`;
}

function renderEdition(edition) {
  const brief = fs.readFileSync(new URL(edition.source, import.meta.url), 'utf8');
  return page({ title: edition.title, description: edition.description, body: marked.parse(brief) });
}

fs.rmSync(new URL('./dist/', import.meta.url), { recursive: true, force: true });
fs.mkdirSync(new URL('./dist/archive/2026-10-07/', import.meta.url), { recursive: true });
fs.mkdirSync(new URL('./dist/archive/2026-10-05/', import.meta.url), { recursive: true });
fs.mkdirSync(new URL('./dist/latest-brief/', import.meta.url), { recursive: true });
fs.mkdirSync(new URL('./dist/archive/', import.meta.url), { recursive: true });

for (const edition of editions) {
  const html = renderEdition(edition);
  fs.writeFileSync(new URL(`./dist/archive/${edition.slug}/index.html`, import.meta.url), html);
  if (edition.slug === '2026-10-07') {
    fs.writeFileSync(new URL('./dist/latest-brief/index.html', import.meta.url), html);
  }
}

const archiveMarkdown = `# African Diaspora Daily Brief Archive

Latest brief: [October 7, 2026](/latest-brief/)

Past editions:

- [October 7, 2026](/archive/2026-10-07/)
- [October 5, 2026](/archive/2026-10-05/)
`;
fs.writeFileSync(new URL('./dist/archive/index.html', import.meta.url), page({
  title: 'African Diaspora Daily Brief Archive',
  description: 'Dated archive of African Diaspora Daily Brief editions.',
  body: marked.parse(archiveMarkdown),
}));

fs.writeFileSync(new URL('./dist/index.html', import.meta.url), renderEdition(editions[0]));

console.log('Brief archive rendered with source links and visuals.');
