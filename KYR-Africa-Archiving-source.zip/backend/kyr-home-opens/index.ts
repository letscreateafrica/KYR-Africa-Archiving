// Public aggregate homepage-open endpoint. No visitor identifiers are stored.
const allowed = new Set([
  'https://african-diaspora-brief.letscreateafrica.chatgpt.site',
  'https://african-diaspora-brief-october-5-2026.letscreateafrica.chatgpt.site',
]);
const headers = (origin: string) => ({
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'content-type',
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'Vary': 'Origin',
});
Deno.serve(async req => {
  const origin = req.headers.get('origin') || '';
  if (!allowed.has(origin)) return new Response('', { status: 403 });
  if (req.method === 'OPTIONS') return new Response('', { headers: headers(origin) });
  if (req.method !== 'POST') return new Response('', { status: 405, headers: headers(origin) });
  const base = Deno.env.get('SUPABASE_URL');
  const key = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!base || !key) return new Response('{"error":"unavailable"}', { status: 503, headers: headers(origin) });
  const url = `${base}/rest/v1/kyr_home_opens`;
  const auth = { apikey: key, Authorization: `Bearer ${key}` };
  try {
    const added = await fetch(url, { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json', Prefer: 'return=minimal' }, body: '{}' });
    if (!added.ok) throw Error(`insert ${added.status}`);
    const counted = await fetch(`${url}?select=id`, { method: 'GET', headers: { ...auth, Prefer: 'count=exact', Range: '0-0' } });
    if (!counted.ok) throw Error(`count ${counted.status}`);
    const range = counted.headers.get('content-range') || '';
    const opens = Number(range.split('/')[1]);
    if (!Number.isSafeInteger(opens)) throw Error('count unavailable');
    return new Response(JSON.stringify({ baseline: 200, recordedOpens: opens, total: 200 + opens }), { headers: headers(origin) });
  } catch (error) {
    console.error('kyr-home-opens', error instanceof Error ? error.message : 'unknown error');
    return new Response('{"error":"unavailable"}', { status: 503, headers: headers(origin) });
  }
});
