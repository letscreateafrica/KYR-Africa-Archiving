'use strict';
// A local archive finder: it never sends the visitor's question to a service.
const form=document.getElementById('guide-form');
const question=document.getElementById('guide-question');
const answer=document.getElementById('guide-answer');
let archive;
const stop=new Set('a an and are as at be can did do for from has have how i in is it me my of on or the there to was were what when where which who why with you your update news brief rights information about'.split(' '));
const terms=s=>[...new Set((String(s).toLowerCase().match(/[\p{L}\p{N}]{2,}/gu)||[]).filter(w=>!stop.has(w)))];
const text=(tag,value,cls)=>{const el=document.createElement(tag);el.textContent=value;if(cls)el.className=cls;return el};
const link=(label,url)=>{const a=text('a',label);a.href=url;a.rel='noreferrer';return a};
const official=[['U.S. visa processes · Department of State','https://travel.state.gov/content/travel/en/us-visas.html'],['Immigration forms and case information · USCIS','https://www.uscis.gov/'],['Immigration court information · DOJ EOIR','https://www.justice.gov/eoir']];
function resources(container){const p=text('p','For current requirements and personal circumstances, check official resources:');container.append(p);const ul=document.createElement('ul');for(const [label,url] of official){const li=document.createElement('li');li.append(link(label,url));ul.append(li)}container.append(ul)}
function search(data,q){const words=terms(q);if(!words.length)return [];
 const issues=new Map((data.newsletters||[]).map(n=>[n.editionId,n]));
 const rows=[];
 for(const e of data.editions||[]){const n=issues.get(e.id);if(!n)continue;
  const pieces=(e.items||[]).length?e.items:[{title:e.title,text:n.summary,sources:[]}];
  for(const i of pieces){const title=i.title||e.title;const hay=[title,i.text,i.place,i.topic,i.status,i.diasporaRelevance,e.date,e.title].join(' ').toLowerCase();let score=0;for(const w of words){if(title.toLowerCase().includes(w))score+=4;else if(hay.includes(w))score+=1;}if(words.some(w=>hay.includes(w)))rows.push({e,i,score:score+((e.date||'')===q.trim()?8:0)});}
 }
 return rows.sort((a,b)=>b.score-a.score||b.e.date.localeCompare(a.e.date)).slice(0,3);
}
function render(q){answer.replaceChildren();const words=terms(q);if(!words.length){answer.append(text('p','Add a topic, place, policy or date to search the dated archive.'));return}
 if(!archive){answer.append(text('p','The archive is unavailable right now.'));resources(answer);return}
 const found=search(archive,q);if(!found.length){answer.append(text('p','I could not find a documented answer in the published archive. This does not mean there is no current update.'));resources(answer);return}
 answer.append(text('p','Matching dated archive entries. Read the full issue and check its linked evidence before acting.'));
 for(const {e,i} of found){const article=document.createElement('article');article.className='guide-result';const heading=text('h3',i.title||e.title);article.append(heading,text('p',`${e.date} · ${i.topic||'Visual newsletter'} · ${i.place||'Coverage note'}`,'meta'),text('p',String(i.text||e.summary||'').slice(0,430)+(String(i.text||e.summary||'').length>430?'…':'')));
 const links=document.createElement('div');links.className='guide-links';links.append(link('Read dated newsletter →',`/newsletter/${e.date}/`));for(const source of (i.sources||[]).filter(s=>s.url&&s.url.startsWith('https://')).slice(0,2))links.append(link(source.title+' ↗',source.url));article.append(links);answer.append(article)}
 answer.append(text('p','These are archived reports, not live answers or individual legal advice. Source dates and coverage limits appear in each issue.','meta'));
}
if(form){
 form.addEventListener('submit',event=>{event.preventDefault();render(question.value)});
 fetch('/data/content.json',{cache:'no-store',credentials:'omit'}).then(r=>{if(!r.ok)throw Error('feed');return r.json()}).then(d=>{archive=d}).catch(()=>{archive=null});
}
const reach=document.getElementById('reach-count');
const reachNote=document.getElementById('reach-note');
if(reach && location.pathname==='/'){
 fetch('https://xmzzthkpiqzzlyhqlagn.supabase.co/functions/v1/kyr-home-opens',{method:'POST',mode:'cors',credentials:'omit',headers:{'Content-Type':'application/json'},body:'{}'})
  .then(r=>{if(!r.ok)throw Error('counter unavailable');return r.json()})
  .then(data=>{if(Number.isSafeInteger(data.total)&&data.total>=200)reach.textContent=data.total.toLocaleString()})
  .catch(()=>{reachNote.textContent='Live count unavailable · launch baseline shown'});
}
