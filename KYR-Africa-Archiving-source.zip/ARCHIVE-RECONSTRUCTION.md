# KnowYourRights Africa source archive

Site version 26 corresponds to source commit `e00d36848c34ca0e8c7696f1374e04575607c557`. Extract this archive, then extract `KYR-Africa-Archiving-source-art.zip` into the same directory to restore `artwork/source-art/`. The Site identity manifest, Git metadata and credentials are omitted. Run `node build.mjs` to rebuild. Editorial images are presentation, not evidence.
