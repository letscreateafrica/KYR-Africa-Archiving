# Archive reconstruction

This is the sanitized source and static build for KnowYourRights Africa Site version 29, source commit ba9e984958c2c2da99b4c7d9dbef5879efb68636.
Extract this source archive, the existing KYR-Africa-Archiving-source-art.zip and the new KYR-Africa-Archiving-source-art-2026-10-21-22.zip into the same directory. The two art archives restore artwork/source-art/. The Site identity manifest, Git history and credentials are omitted. The published static pages are in dist/.