# Public source archive

Site source commit: 84ab8b9e557e2575ef4941ad12a6d5ab55097156
Published on existing KnowYourRights Africa Site as version 25 on October 19, 2026.

This archive excludes Git history and the Site identity manifest under .openai. Original composition inputs are in the companion KYR-Africa-Archiving-source-art.zip; extract that ZIP into artwork/source-art/ after extracting this archive. The built public site is included in dist/.
