# Archive reconstruction

Sanitized source and static build for the existing public KnowYourRights Africa Site version 30, source commit 61a32b5e143966e8fe41f1d2af2a73421c5e9f81. The published October 23–26 dated pages are in dist/.

Extract this source archive, the existing KYR-Africa-Archiving-source-art.zip, the October 21–22 original-art delta ZIP, and this October 23–26 original-art delta ZIP into the same directory. The art archives restore artwork/source-art/. Site identity manifest, Git history and credentials are omitted.